
import os
import math
import sys
import numpy as np
from collections import OrderedDict

train_file_yes = ["test1.clean", "test2.clean"]
train_file_no = ["test3.clean", "test4.clean"]

def read_file(train_file_yes, train_file_no):
	vocab_type1 = OrderedDict()
	vocab_type2 = OrderedDict()
	count_words_yes = 0
	count_words_no = 0
	for filename in train_file_yes:
		word_list = open(filename, 'r').read().split()
		print word_list
		count_list = [] # to calculate number of different files for vocab_type2
		for word in word_list:
			count_words_yes += 1
			if word not in vocab_type1:
				vocab_type1[word] = [1, 0]
			else:
				vocab_type1[word][0] += 1
				
			if word not in vocab_type2:
				vocab_type2[word] = [1, 0]
				count_list.append(word)
			else:
				if word not in count_list:
					vocab_type2[word][0] += 1
					count_list.append(word)
	#print vocab_type2

				
	for filename in train_file_no:
		word_list = open(filename, 'r').read().split()
		print word_list
		count_list = []
		for word in word_list:
			count_words_no += 1
			if word not in vocab_type1:
				vocab_type1[word] = [0, 1]
			else:
				vocab_type1[word][1] += 1
			if word not in vocab_type2:
				vocab_type2[word] = [0, 1]
				count_list.append(word)
			else:
				if word not in count_list:
					vocab_type2[word][1] += 1
					count_list.append(word)
	#print vocab_type1
	print vocab_type2
	return vocab_type1, vocab_type2, count_words_yes, count_words_no

def main():
	vocab_type1, vocab_type2, count_words_yes, count_words_no = \
			read_file(train_file_yes, train_file_no)
	return
main()